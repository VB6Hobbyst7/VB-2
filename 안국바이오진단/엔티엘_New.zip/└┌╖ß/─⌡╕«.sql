Select M.WNIFDPCD
     , M.WNIFDATE
     , M.WNIFSLIP
     , M.WNIFITEM
     , M.WNIFIORO
     , M.WNIFWKNO
     , M.WNIFIDNO
     , M.WNIFNAME
     , M.WNIFBIRT
     , M.WNIFRSEX
     , R.CPNWCODE
 From arcwnifh M
    , arccpnwh R
 Where M.wnifdpcd = R.cpnwdpcd 
   and M.wnifdate = R.cpnwdate 
   and M.wnifslip = R.cpnwslip 
   and M.wnifioro = R.cpnwioro 
   and M.wnifidno = R.cpnwidno 
   and M.wnifwkno = R.cpnwwkno 
   and R.cpnwstsf < '5'      
   and M.wnifsmyy = 13 
   and M.wnifsmsq = 0296670
   and M.wnifsmsb = 1
   and M.wnifsms1 = 3

