select WNIFDPCD
     , WNIFDATE 
     , WNIFSLIP 
     , WNIFITEM 
     , WNIFIORO
     , WNIFWKNO 
     , WNIFIDNO
     , WNIFNAME
     , WNIFBIRT
     , WNIFRSEX
     , WNIFWARD
     , WNIFROOM
     , WNIFDEPT
     , WNIFSMYY 
     , WNIFSMSQ 
     , WNIFSMSB 
     , WNIFSMS1 
from arcwnifh
where WNIFIORO = 'A'
  and WNIFDPCD = 'PA'
  and WNIFDATE between '20130300' and '20130314'
  and WNIFSLIP = 'L81'
  and WNIFITEM = '11'
  and WNIFWKNO between 756 and 850 
  order by WNIFWKNO
