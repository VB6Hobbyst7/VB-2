 select M.LabRegDate                               
      , M.LabRegNo                                 
      , M.CompCode                                 
      , M.PatientName                              
      , M.PatientChartNo                           
      , M.PatientJuminNo01                         
      , M.PatientJuminNo02                         
      , M.PatientAge                               
      , M.PatientSex                               
      , C.CompName as CompanyName                  
      , R.OrderCode                                
      , R.TestCode                                 
      , R.TestSubCode                              
      , R.TestResult01                             
 From LabRegTest J                                 
    , LabRegInfo M                                 
    , LabRegResult R                               
    , ProgCompCode C                               
 Where R.LabRegDate = :ADT                         
   and R.LabRegNo = :WNO                           
   and J.LabRegDate = M.LabRegDate                 
   and J.LabRegNo = M.LabRegNo                     
   and J.LabRegDate= R.LabRegDate                  
   and J.LabRegNo = R.LabRegNo                     
   and J.OrderCode = R.OrderCode                   
   and J.TestCode = R.TestCode                     
   and M.CompCode = C.CompCode                     
