   begin                                   
   declare                                 
   @StatustIndex         tinyint,          
   @WorkListCode         varchar(50),      
   @BeginDate         smalldatetime,       
   @EndDate         smalldatetime,         
   @BeginNo         int,                   
   @EndNo         int,                     
   @TestCodes         varchar(200)         
     set @StatustIndex = 0                 
     set @WorkListCode = 'WC33'          
     set @BeginDate='2013-03-19' 
     set @EndDate='2013-03-19'   
     set @BeginNo=96	        
     set @EndNo=99           
     set @TestCodes = ''                 
  execute Interface_GetPatientResultList02 @StatustIndex , @WorkListCode,  @BeginDate,  @EndDate,  @BeginNo,  @EndNo,  @TestCodes
  end 
