 begin                             
 declare                           
 @LabRegDate 		smalldatetime,  	
 @LabRegNo 		int,		            
 @OrderCode 		varchar(20),	      
 @TestCode 		varchar(20),	      
 @TestSubCode 		varchar(20),	    
 @TestResult01 		varchar(50),	  
 @TestResult02 		varchar(50),	  
 @TestResultAbn 		varchar(50),	  
 @IsPanic 		bit,		              
 @IsDelta 		bit,		              
 @IsCritical 		bit,		          
 @Result 		bit             	    
 set @LabRegDate = '2013-03-19'    
 set @LabRegNo = 96                
 set @OrderCode = 'DNAPCR-����' 		
 set @TestCode = 'DNAPCR-����'     
 set @TestSubCode = 'CH016'        
 set @TestResult01 = 'Negative'    
 set @TestResult02 = 'Negative'            
 set @TestResultAbn = ''           
 set @IsPanic = 0                  
 set @IsDelta = 0                  
 set @IsCritical = 0               
 execute Interface_SetPatientResult @LabRegDate, @LabRegNo, @OrderCode, @TestCode, @TestSubCode, @TestResult01, @TestResult02,  @TestResultAbn, @IsPanic, @IsDelta, @IsCritical, @Result  
 End 
