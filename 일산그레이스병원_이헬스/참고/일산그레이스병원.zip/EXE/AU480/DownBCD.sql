 select OBSUCODE              
 from OBSURSTM                
 where OBSULBNO = '201312100060' 
 And (OBSURSLT = '' or OBSURSLT is null) 
 Order By OBSUORSQ 
