# 사용자 동의 저장 경로
`HKEY_CURRENT_USER\Software\Cellestis\2.62`
