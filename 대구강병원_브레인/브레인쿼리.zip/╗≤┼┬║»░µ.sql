 Update AspsLabw                     
    set sLabw_status = '2'         
  where sLabw_date = '20120423'     
    and sLabw_cnt  = 34         
    and sLabw_cham = '0000007759'     
    and sLabw_status < '2'         
    and sLabw_Hid  = 150000          
