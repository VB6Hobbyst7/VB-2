 Update AspsLabws                    
    set sLabws_result = '163'  
  where sLabws_date = '20120423'    
    and sLabws_cnt  = 34        
    and sLabws_momu = 'B2590'    
    and sLabws_sCnt = 10        
    and sLabws_Hid  = 150000         
