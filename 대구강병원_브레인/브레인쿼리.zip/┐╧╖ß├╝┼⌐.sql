 Select sLabws_cnt From AspsLabws   
 where sLabws_result = 0            
   and sLabws_date = '20120423'    
   and sLabws_cnt  = 34        
   and sLabws_Hid  = 150000         
