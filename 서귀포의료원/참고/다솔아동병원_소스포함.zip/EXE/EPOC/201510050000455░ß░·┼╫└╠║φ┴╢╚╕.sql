 select * from TB_H131_SPPRESULT  
  where H131_SEQNO = '201510050000455'            
    and H131_SPPTYPE = 'L010'      
