-----   Release Notes   ----- ----- ----- ----- -----
Windows-xp Driver Update : 31-Aug-2002
----- ----- ----- ----- ----- ----- ----- ----- -----



-----   Products Affected :   ----- ----- ----- -----
Nm9835 : PCI to Dual UART, and one 1284 Printer Port
Nm9845 : PCI to Dual UART, and ISA Bridge
----- ----- ----- ----- ----- ----- ----- ----- -----



-----   Purpose :       ----- ----- ----- ----- -----
The Windows-xp Drivers have been revised to correct a problem seen by the Nm9835 and Nm9845 devices when they are used to provide only Serial Port interfaces, no Parallel Port is configured.  With this configuration, the computer would freeze up whenever a device connected to a Serial Port (Modem, Printer, etc.) was turned ON or OFF, or when a cable was plugged in or unplugged.  Interrupts were being generated, and no handler was provided to deal with them.  The problem was traced back to the circuitry of these devices that was not being used.
----- ----- ----- ----- ----- ----- ----- ----- -----



-----   Changes :       ----- ----- ----- ----- -----
This new Driver configures a "dummy" Parallel Port when needed to insure the interrupts will always be handled.  When installed on a card that configures only Serial Ports, a new device (NetMos Unusable Parallel Port) will appear in the Device Manager along with the other devices in the "Ports (COM and LPT)" section.  If the NetMos Parallel Port is configured on the board, it will show up normally, no change from previous versions.
----- ----- ----- ----- ----- ----- ----- ----- -----



-----   Installation :  ----- ----- ----- ----- -----
For best results, "Uninstall" the existing Drivers, then install these updated Drivers.  If possible, the Drivers should be installed when there are no external devices connected to the Ports (unplug any modems or printers etc.)  If you can not disconnect the external devices when installing the Drivers, please turn the devices OFF.  This will insure they do not generate interrupts, or try to transfer data before the Driver is fully installed and ready to respond to such activity.
----- ----- ----- ----- ----- ----- ----- ----- -----



-----   General Use :         ----- ----- ----- -----
Despite the claim "Everyone else does it..." neither Serial nor Parallel devices are supposed to be connected or disconnected while the power is applied.  All connections should be made with all equipment (computer and external devices) OFF.  External Serial or Parallel devices should then have power applied, and finally, the power to the computer should be applied.  When powering down, the reverse is true; turn the computer OFF, then turn the external devices OFF.
----- ----- ----- ----- ----- ----- ----- ----- -----

