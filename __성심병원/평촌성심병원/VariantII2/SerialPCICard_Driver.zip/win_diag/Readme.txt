How To install?
===============
Run NetMosWinNTPciDIagnostics.exe
(This self extracting install shield file installs
a windows nt application named NmDiag.Exe in the
<ProgramFilesDirectory>\netmos directory. Typically 
this is c:\Program Files\Netmos\NmDiag.Exe

How To Use?
===========
Run c:\Program Files\Netmos\NmDiag.Exe

Netmos.Log file
===============
The app creates a log file named netmos.log in the 
current directory, from where the app was started. 
Typically this is c:\Program Files\Netmos\Netmos.Log

Tips for better support?
========================
If you are facing problems with the NetMos cards, 
please email the c:\Program Files\Netmos\Netmos.Log
file to NetMos Driver support team. Please refer to 
www.netmos.com for email address. This log file will 
be of great help for us to provide better support 
for you.

How does the NmDiag.exe program work?
=====================================
This NetMosWinNTPciDiagnostics.exe package come with two executables
listed below.
    NmDiag.Exe :  the windows nt application.
    NmDiag.Sys :  the windows nt driver.
The NmDiag.exe is installed in the <ProgramFilesDirectory>\netmos directory.
The NmDiag.sys is installed in the <WINNT root>\System32\Drivers directory.
The NmDiag.exe application will work  only if the NmDiag.sys driver is
installed properly.