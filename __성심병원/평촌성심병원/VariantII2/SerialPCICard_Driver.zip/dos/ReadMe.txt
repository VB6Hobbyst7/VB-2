NetMos DOS installer version 1.00.024 dated 19-DEC-2001.
Usage : NmDosIn [<options>]By default, NmDosIn displays COM/LPT ports.

Options
   -a[dd]                    = Add NetMos Ports
   -c[onfig]:<parameters>    = Configure NetMos Ports
   -d[elete]                 = Delete NetMos Ports
   -r[emap]                  = Remap NetMos ports to legacy ports
   -s[ilent]                 = Silent mode
   -t[est]                   = Test ports (requires external Loop-Back plugs)
   -u[nused]                 = remap to all Unused legacy port i/o base, 
                               without consideration of COM/LPT number

Config Option Parameters
    -c[onfig]:lpt[1|2|3]=[spp|bpp|ppf|epp|ecp]
    e.g., -config:lpt=spp would set all LPT ports to SPP
    e.g., -c:lpt1=spp would set lpt1 to SPP
    e.g., -c:lpt1=spp,lpt2=bpp would set lpt1 to SPP and lpt2=BPP
